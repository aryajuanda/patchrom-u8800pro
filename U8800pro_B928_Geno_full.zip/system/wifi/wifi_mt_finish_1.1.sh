#!/bin/sh
rmmod dhd
